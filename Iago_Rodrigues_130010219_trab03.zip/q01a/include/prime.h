#ifndef PRIME_H
#define PRIME_H

int generate_prime();
int test_prime(int prime);

enum { NOT_PRIME, PRIME };

#endif